package johnBJackMedTest;

public enum Suit {
	H, S, D, C;
}
